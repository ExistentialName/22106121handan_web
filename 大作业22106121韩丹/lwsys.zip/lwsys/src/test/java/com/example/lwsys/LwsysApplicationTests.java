package com.example.lwsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LwsysApplicationTests {

    @Test
    void contextLoads() {
    }

}
