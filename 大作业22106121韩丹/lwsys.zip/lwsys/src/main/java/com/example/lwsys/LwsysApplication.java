package com.example.lwsys;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.example.lwsys.dao")
public class LwsysApplication {

    public static void main(String[] args) {
        SpringApplication.run(LwsysApplication.class, args);
    }

}
